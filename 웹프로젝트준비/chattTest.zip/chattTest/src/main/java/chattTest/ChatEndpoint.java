package chattTest;

 

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
/*
@ServerEndpoint("/chat")
public class ChatEndpoint {

    private static Set<Session> clients = new HashSet<>();

    @OnOpen
    public void onOpen(Session session) {
        clients.add(session);
    }

    @OnMessage
    public void onMessage(String message, Session sender)
            throws IOException {

        for(Session s : clients) {
            s.getBasicRemote().sendText(message);
        }
    }

    @OnClose
    public void onClose(Session session) {
        clients.remove(session);
    }
}
*/
 

import java.io.IOException;
import java.util.*;
import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/chat")
public class ChatEndpoint {

    private static Set<Session> clients = new HashSet<>();
    private static Map<Session,String> names = new HashMap<>();

    @OnOpen
    public void onOpen(Session session) throws IOException {

        String query = session.getQueryString(); // nick=민수
        String nick = query.split("=")[1];

        clients.add(session);
        names.put(session, nick);

        broadcast("[" + nick + "님 입장하셨습니다]");
    }

    @OnMessage
    public void onMessage(String msg, Session session)
            throws IOException {

        String nick = names.get(session);

        broadcast(nick + ": " + msg);
    }

    @OnClose
    public void onClose(Session session) throws IOException {

        String nick = names.get(session);

        clients.remove(session);
        names.remove(session);

        broadcast("[" + nick + "님 퇴장하셨습니다]");
    }

    private void broadcast(String msg) throws IOException {
        for(Session s : clients) {
            s.getBasicRemote().sendText(msg);
        }
    }
}