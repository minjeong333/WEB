package chattTest;
 

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/chat")
public class ChatEndpoint2 {

    private static Set<Session> clients = new HashSet<>();
    private static Map<Session,String> names = new HashMap<>();

    @OnOpen
    public void onOpen(Session session) throws IOException {

        String query = session.getQueryString();
        String nick = "손님";

        if(query != null && query.startsWith("nick=")){
            nick = query.substring(5);
            nick = URLDecoder.decode(nick, StandardCharsets.UTF_8);
        }

        clients.add(session);
        names.put(session, nick);

        broadcast("[" + nick + "님 입장]");
        showUserList();
    }

    @OnMessage
    public void onMessage(String msg, Session session) throws IOException {

        String sender = names.get(session);

        // 귓속말 형식: /w 토끼 안녕
        if(msg.startsWith("/w ")){

            String[] arr = msg.split(" ",3);

            if(arr.length == 3){
                String targetNick = arr[1];
                String whisperMsg = arr[2];

                whisper(sender, targetNick, whisperMsg);
            }

        }else{
            broadcast(sender + ": " + msg);
        }
    }

    @OnClose
    public void onClose(Session session) throws IOException {

        String nick = names.get(session);

        clients.remove(session);
        names.remove(session);

        broadcast("[" + nick + "님 퇴장]");
        showUserList();
    }

    // 전체 메시지
    private void broadcast(String msg) throws IOException {
        for(Session s : clients){
            s.getBasicRemote().sendText(msg);
        }
    }

    // 접속자 목록 표시
    private void showUserList() throws IOException {

        StringBuilder sb = new StringBuilder();
        sb.append("[현재 인원 ").append(clients.size()).append("명] ");

        for(String nick : names.values()){
            sb.append(nick).append(" ");
        }

        broadcast(sb.toString());
    }

    // 귓속말
    private void whisper(String sender,
                         String targetNick,
                         String msg) throws IOException {

        for(Session s : clients){

            if(names.get(s).equals(targetNick)){
                s.getBasicRemote()
                 .sendText("[귓속말] " + sender + ": " + msg);
            }
        }
    }
}