<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>채팅방</title>
</head>
<body>

닉네임: <input type="text" id="nick">
<button onclick="enterRoom()">입장</button>

<hr>

<input type="text" id="msg">
<button onclick="sendMsg()">전송</button>

<ul id="list"></ul>

<script>
let ws;
let nickname;

function enterRoom() {
    nickname = document.getElementById("nick").value;

    ws = new WebSocket(
      "ws://localhost:8080/chattTest/chat?nick=" + encodeURIComponent(nickname)
    );

    ws.onmessage = function(e){
        let li = document.createElement("li");
        li.innerText = e.data;
        document.getElementById("list").appendChild(li);
    }
}

function sendMsg(){
    let msg = document.getElementById("msg").value;
    ws.send(msg);
}
</script>

</body>
</html>