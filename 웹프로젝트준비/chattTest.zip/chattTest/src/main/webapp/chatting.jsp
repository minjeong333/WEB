 
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>채팅방</title>

<style>
body{
    font-family: 맑은 고딕;
    margin:30px;
}
#list{
    border:1px solid #ccc;
    width:500px;
    height:350px;
    overflow:auto;
    padding:10px;
    list-style:none;
}
#list li{
    margin:5px 0;
}
input{
    padding:5px;
}
button{
    padding:6px 10px;
}
</style>

</head>
<body>

<h2>웹소켓 채팅방</h2>

닉네임 :
<input type="text" id="nick">
<button onclick="enterRoom()">입장</button>

<hr>

메시지 :
<input type="text" id="msg" style="width:300px;"
       onkeypress="if(event.key==='Enter') sendMsg();">

<button onclick="sendMsg()">전송</button>

<p>
귓속말 사용법 :
<b>/w 닉네임 메시지</b><br>
예) /w 거북이 안녕
</p>

<ul id="list"></ul>

<script>
let ws;
let nickname;

// 입장
function enterRoom(){

    nickname = document.getElementById("nick").value.trim();

    if(nickname==""){
        alert("닉네임 입력하세요.");
        return;
    }

    ws = new WebSocket(
        "ws://localhost:8080/chattTest/chat?nick="
        + encodeURIComponent(nickname)
    );

    ws.onopen = function(){
        addMsg("서버 연결 완료");
    }

    ws.onmessage = function(e){
        addMsg(e.data);
    }

    ws.onclose = function(){
        addMsg("서버 연결 종료");
    }
}

// 메시지 출력
function addMsg(msg){

    let li = document.createElement("li");
    li.innerText = msg;

    document.getElementById("list").appendChild(li);

    let list = document.getElementById("list");
    list.scrollTop = list.scrollHeight;
}

// 전송
function sendMsg(){

    let msgObj = document.getElementById("msg");

    let msg = msgObj.value.trim();

    if(msg==""){
        return;
    }

    if(ws == null){
        alert("먼저 입장하세요.");
        return;
    }

    ws.send(msg);

    msgObj.value = "";
    msgObj.focus();
}
</script>

</body>
</html>